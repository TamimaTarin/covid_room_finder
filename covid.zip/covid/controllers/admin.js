var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var userModel = require.main.require('./models/user-model');
var adminModel = require.main.require('./models/admin-model');


//Login
router.get('/',function(req,res){	
	res.render('admin/index');
	
});

//view_room

router.get('/viewroom', function(req, res){
	
		adminModel.getAll(function(results){
			if(results.length > 0){
				res.render('admin/viewroom', {room_list: results});
			}else{
				res.redirect('/admin');
			}
		});
});

//Add Room
router.get('/addroom',function(req,res){		
	res.render('admin/addroom');		
	});

router.post('/addroom',function(req,res){		
	var room_list =
	{		
		roomname:    req.body.roomname,
		max_number:    req.body.max_number,
	}
	console.log(room_list);
	adminModel.insertroom(room_list, function(status){
		console.log(status);
			if(status){
				
				adminModel.getroomId(room_list,function(result){
					
					room_list.roomid = result.roomid;
					res.redirect('/admin/viewroom');
                });
}else{
				res.send("Failed");
			}
		});

//cancel room
router.get('/cancel/:roomid', function(req, res){
	var room_list = {
			roomname : req.body.roomname,
			max_number :req.body.max_number,
		};
	
 adminmodel.delete(roomid, function(status){
			if(status){
				console.log(status);
				res.redirect('/admin');
			}else{
				res.redirect('/admin/cancel');
			}
		});
});

});

module.exports = router;
