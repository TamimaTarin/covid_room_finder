var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var userModel = require.main.require('./models/user-model');


//Login
router.get('/',function(req,res){	
	res.render('User/index');
	
});

//Booking
router.get('/booking',function(req,res){		
	res.render('User/booking');		
	});

router.post('/booking',function(req,res){		
	var booking =
	{		
		roomname: req.body.roomname,
		date:     req.body.date,
		username: req.body.username,
	}
	console.log(booking);
	userModel.insertbooking(booking, function(status){
		console.log(status);
			if(status){
				
				userModel.getbookId(user,function(result){
					
					booking.bookid = result.bookid;
					res.redirect('/User');
                });
}else{
				res.send("Failed");
			}
		});

});
module.exports = router;
