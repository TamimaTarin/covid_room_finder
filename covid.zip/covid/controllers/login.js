var express 	= require('express');
var router 		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var userModel = require.main.require('./models/user-model');

//Login

router.get('/', function(req, res){
	console.log('login page requested!');
	res.render('login/index');
});

router.post('/', function(req, res){
		
		var user ={
			username: req.body.username,
			password: req.body.password
		};
		loginModel.validate(user, function(status){
			if(status){
				loginModel.getType(user, function(result){
					console.log('Here');
					var type = JSON.stringify(result.type.toString());
                    console.log(type);
					console.log(status);
					if(type=='"admin"'){	
						res.redirect('/admin');
					}
					else if(type=='"user"'){			
						res.redirect('/User');
					}
                    else{
							
						res.redirect('/login');
					}
				});
				
			}else{
				res.redirect('/login');
			}
		});
});



//Registration
router.get('/registration?',function(req,res){		
	res.render('login/registration');		
	});

router.post('/registration?',function(req,res){		
	var user =
	{		
		username:    req.body.username,
		password:    req.body.password,
	}
	console.log(user);
	userModel.insertuser(user, function(status){
		console.log(status);
			if(status){
				
				userModel.getuserId(user,function(result){
					
					user.userid = result.userid;
					user.type = 'user';
					res.redirect('/login');
                });
}else{
				res.send("username already exist");
			}
		});
	});


module.exports = router;
