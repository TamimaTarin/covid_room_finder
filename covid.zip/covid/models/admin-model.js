var db = require('./db');

module.exports ={

	
getAll : function(callback){
		var sql = "select * from room_list ";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	

	insertroom: function(room_list, callback){
		var sql = "insert into room_list values(?,?,?)";
		db.execute(sql, [null,room_list.roomname,room_list.max_number], function(status){
			console.log(status);
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	getroomId:function(room_list, callback){
		var sql = "select roomid from room_list where roomname=? and max_number=?";
		db.getResult(sql, [room_list.roomname,room_list.max_number], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	
	delete: function(roomid, callback){
		var sql = "delete from room_list where roomid=?";
		db.execute(sql, [room_list.roomid], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	
	
}