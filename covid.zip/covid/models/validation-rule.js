const { check,sanitizeBody } = require('express-validator');
exports.form=[
  //  Name validation
  check('username').trim().notEmpty().withMessage(' Name required')

  // password validation
  check('password').trim().notEmpty().withMessage('Password required')
  .isLength({ min: 6 }).withMessage('password must be minimum 6 length')
  .matches(/(?=.*?[#?!@$%^&*-])/).withMessage('At least one special character')
  
  ]