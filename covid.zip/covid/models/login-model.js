var db = require('./db');

module.exports ={

	validate: function(user, callback){
		var sql = "select * from user where username=? and password=?";
		var sqlPrint = "select * from user where username="+user.username+" and password="+user.password+";";
		db.getResult(sql, [user.username, user.password], function(result){
			if(result.length > 0){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	getType: function(user, callback){
		var sql = "select type from user where username=? and password=?";
		var sqlPrint = "select type from user where username="+user.username+" and password="+user.password+";";
		db.getResult(sql,[user.username, user.password], function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	}
}