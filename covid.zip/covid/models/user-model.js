var db = require('./db');

module.exports ={
	
	insertuser: function(user, callback){
		var sql = "insert into user values(?,?,?,?)";
		db.execute(sql, [null,user.username,user.password,'user'], function(status){
			console.log(status);
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	insertbooking: function(booking, callback){
		var sql = "insert into booking values(?,?,?,?)";
		db.execute(sql, [null,booking.roomname,booking.date,booking.username], function(status){
			console.log(status);
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	

	getbookId : function(bookid, callback){
		var sql = "select * from booking where bookid=?";
		db.getResult(sql, [bookid] , function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	
	
	getuserId:function(user, callback){
		var sql = "select userid from user where username=? and password=?";
		db.getResult(sql, [user.username,user.password], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	}
}
